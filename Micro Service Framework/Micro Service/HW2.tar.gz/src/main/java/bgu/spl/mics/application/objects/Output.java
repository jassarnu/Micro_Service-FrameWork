package bgu.spl.mics.application.objects;

import java.util.List;

public class Output {
    List students;
    ConfrenceInformation[] confrenceInformations;
    int cpuTimeUsed;
    int gputimeUsed;
    int batchesProcessed;
    public Output(){
        //students.add()

    }

}
